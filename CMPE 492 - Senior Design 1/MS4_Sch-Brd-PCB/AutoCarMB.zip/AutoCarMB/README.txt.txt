================================================================
Project Name:	Autocar
Institution:	California State University East Bay
Class:		CMPE 492 - Senior Design I
Professor:	Professor James Tandon
Team Name:	Autonomous Car
Team Members:	Eric Fong
		Christian Alcalde
		Abdullah Wardak
================================================================
* manufacture 2 sets of boards
* professionally assemble 1 set
* manually assemble 1 set