================================================================
Project Name:	Autocar
Institution:	California State University East Bay
Class:		CMPE 492 - Senior Design I
Professor:	James Tandon
Team Name:	Autonomous Car
Team Members:	Eric Fong
		Christian Alcalde
		Abdullah Wardak
================================================================
* manufacture only for the two IRBumper boards, and one AutoCar board
* professionally assemble 1 copy of the main AutoCar board
* manually assemble both IRBumper boards and one AutoCar board
